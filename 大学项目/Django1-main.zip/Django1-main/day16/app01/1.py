a="asv"
print(a.upper())